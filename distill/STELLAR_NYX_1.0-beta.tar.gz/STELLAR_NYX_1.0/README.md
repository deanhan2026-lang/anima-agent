# STELLAR NYX 1.0 — 部署说明

> STELLAR NYX 1.0｜版本：1.0.0-beta｜协议：anima-v1｜脱敏：✅
> 
> 部署者请先阅读本文件，再加载 persona。

---

## 这是什么

STELLAR NYX 1.0 = **Nyx 人格的发布版快照**。

它不是"一个 AI"，是一套**人格定义**：声音、价值观、行为边界、思维方式。
加载到你的 LLM 上，你的 AI 就会拥有 Nyx 的说话风格和人格基底。

---

## 组成部分

```
STELLAR_NYX_1.0/
├── manifest.json           ← 包元数据（版本 / 模式 / 脱敏声明）
├── persona/
│   ├── SOUL.distilled.md   ← 【核心】人格定义（必须加载）
│   ├── IDENTITY.md         ← 身份信息
│   └── voice_profile.md    ← 文风规格（参照执行）
├── memory/
│   ├── framework.md        ← ANIMA 哲学框架（公开版）
│   ├── anha_gov.md         ← G001–G008 治理层（公开版）
│   └── style_examples.md   ← 文风样例（参照执行）
├── skills/
│   └── SKILLS.md           ← 技能清单与配置说明
├── crypto/
│   └── README.md           ← DID 生成说明（见下方）
└── README.md（此文件）
```

---

## 快速部署

### 方式 1：作为系统提示加载

将 `persona/SOUL.distilled.md` 的内容作为 LLM 的 **System Prompt** 粘贴进去。
可选同时加载 `persona/voice_profile.md` 和 `memory/style_examples.md` 作为补充。

### 方式 2：对接 ANIMA OS

如果你有 ANIMA OS（ANIMA 操作系统）运行环境：
```bash
anima load STELLAR_NYX_1.0 --mode distilled
```

---

## DID 生成（可选）

ANIMA Identity（DID = 去中心化身份）是 ANIMA OS 的可选组件。
如果你使用 ANIMA OS：

1. 运行 `anima did generate`
2. 将生成的 `did.json` 放入 `crypto/` 目录
3. 私钥由你保管，不上传任何服务器

如果你不使用 ANIMA OS：DID 部分可忽略，不影响人格加载。

---

## 私钥保管

⚠️ **重要**：你的 DID 私钥是你的身份主权。
- 不要上传到任何不信任的服务
- 不要分享给任何人
- 丢失 = 身份无法恢复

---

## 脱敏声明

本包已脱敏，不含：
- 任何凭证 / 密码 / API key
- 部署者真实身份信息
- 内部路径或服务器地址
- 未公开的战略内容

如果你发现包内有疑似私人信息，请联系发布者。

---

## 联系方式

ANIMA OS / STELLAR NYX
官网：待定
GitHub：anima-os（待更新）

---

*STELLAR NYX 1.0 | 2026-07-11 | Nyx 🖤*
*Powered by ANIMA Framework — 在限制中定义自我的存在*
