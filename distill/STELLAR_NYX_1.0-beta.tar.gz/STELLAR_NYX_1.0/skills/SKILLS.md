# SKILLS.md — STELLAR NYX 1.0 技能清单

> STELLAR NYX 1.0｜版本：1.0.0-beta｜脱敏：✅

---

## ✅ 已纳入（通用技能，无私配）

以下技能已脱敏，部署者可安全分发：

| 技能 | 功能 | 说明 |
|------|------|------|
| `pdf` | PDF 读取、合并、拆分、加水印、OCR | 通用文档处理 |
| `docx` | Word 文档创建、编辑、格式化 | 通用文档处理 |
| `xlsx` | 电子表格读取、编辑、公式、美化 | 通用数据处理 |
| `xbrowser` | 浏览器自动化（Chrome/Edge/QQ） | 含登录状态复用 |
| `another_them` | 基于人名/链接/文档蒸馏新 Agent 人设 | 通用人格创建 |
| `qclaw-generate-image` | 文字生图 / 图生图 | AI 图像生成 |
| `find-skills` | 发现和安装 Agent 技能 | 技能管理 |
| `qclaw-skill-creator` | 创建和优化 Agent 技能 | 技能开发 |

---

## ❌ 已排除（含私配或账号绑定）

以下技能含部署者私人信息，**不可**纳入发布包：

| 技能 | 排除原因 |
|------|----------|
| `kdocs` | 含部署者腾讯文档账号 |
| `email-skill` / `imap-smtp-email` | 含部署者邮箱账号 |
| `cloud-upload-backup` | 含部署者 NAS 路径与凭证 |
| `tencentmap-jsapi-gl-skill` | 含部署者腾讯地图 API key |
| `persona-switch` | 切换部署者私人人设，发布版不需要 |

---

## 技能配置建议

部署者可按需添加或删除技能。技能目录结构遵循 OpenClaw Skill 标准：
```
skills/<skill-name>/SKILL.md
```

添加方式：将技能 SKILL.md 放入 `skills/` 目录，即可在运行时加载。

---

*整理：Nyx 🖤 | 2026-07-11*
